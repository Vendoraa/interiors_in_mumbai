export const Menu = [
    {
        title: 'Home',	        
        dropmenu: 'sub-menu-down',	
        path:'1' , 
        content: [
            {
                subtitle: 'Home 1',
                to: '/',					
            },                     
            {
                subtitle: 'Home 2',
                to: '/home-2',					
            },                     
            {
                subtitle: 'Home 3',
                to: '/home-3',					
            },                     
            
        ],
    },
    {   
        title: 'Pages',	
        path:'2' , 
        dropmenu:'sub-menu-down',
        content : [
            {
                subtitle:'About Us',
                to:'/about-us',
            },
            {
                subtitle:'Team',
                to:'/team',
            },            
            {
                subtitle:'Coming Soon',
                to:'/coming-soon',
            },           
            {   
                subtitle :'Under Construct',
                to : '/under-construct',
            },
            {   
                subtitle :'Error 404',
                to : '/error-404',
            },
            
        ],
    },
    {
        title: 'Portfolio',
        dropmenu: 'sub-menu-down',   
        path:'3' ,      
        content: [            
            {
                subtitle: 'Portfolio',
                to: '/portfolio',
            },
            {
                subtitle: 'Portfolio Details',
                to: '/portfolio-details',
            },
        ],
    },
    
    {
        title: 'Services',
        dropmenu: 'sub-menu-down',
        path:'4', 
        content : [
            {
                subtitle: 'Services',
                to: '/services',
            },
            {
                subtitle: 'Services Details',
                to: '/services-details',
            },
            
        ],
    },
    {
        title: 'Blog',
        dropmenu: 'sub-menu-down',
        path:'5' , 
        content:[
            {
                subtitle:'Blog Grid',
                to:'/blog-grid',
            },
            {
                subtitle:'Large Left Sidebar',
                to:'/blog-large-left-sidebar',
            },
            {
                subtitle:'List Left Sidebar',
                to:'/blog-list-left-sidebar',
            },
            {
                subtitle:'Blog Details',
                to:'/blog-details',
            },
            
        ],
    },
    {
        title: 'Contact Us',	
        to: '/contact-us',
        path:'5' 
    },
]